leeftijd = int(input('wat is uw leeftijd'))
snor = str(input('heeft u een snor antwoord ja/nee'))
diploma = str(input('heeft u een diploma antwoord ja/nee'))

if (leeftijd >=18 and snor == 'ja') or (leeftijd <=18 and diploma == 'ja'):
    print ("u bent aangenomen")

else:
    print("sorry u bent niet aangenomen")