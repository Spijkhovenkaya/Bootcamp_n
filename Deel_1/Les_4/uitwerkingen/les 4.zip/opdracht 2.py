# ik grijg dezelfde uitkomst
print( 5*2 -3+4/2 )
print( 5*2 - 3+4 / 2 )
# de getallen zijn hetzelfde maar te haakjes en min staan anders
print( (5*2) - (3+4) /2 )
print( ((5*2) -(3+4)) / 2 )