getal = int(input("Voer een getal in: "))

if getal % 7 == 0 and getal % 11 == 0:
    print("Dit getal is zonder rest deelbaar door 7 en 11")
else:
    print("Dit getal is niet zonder rest deelbaar door 7 en 11")