getal1 = int(input("Geef een getal: "))
getal2 = int(input("Geef een tweede getal: "))
getal3 = int(input("Geef een derde getal: "))

antwoord = (getal1 + getal2 + getal3)
eindantwoord = (f"De som van {getal1} + {getal2} + {getal3} = {antwoord}")