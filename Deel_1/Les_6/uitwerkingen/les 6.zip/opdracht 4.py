a = 3
b = 3
print(a == b)  

s = "hallo"
print(s == "hallo")

a = 15
print(10 <= a < 20)  

b = 5
print(b < 10 or b > 20) 

a = 4
print(a % 2 == 0)  