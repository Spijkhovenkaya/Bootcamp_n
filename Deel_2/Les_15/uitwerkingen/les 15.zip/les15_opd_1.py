def sommeer(getal1, getal2): # parameters kun je gebruiken als var in je functie
    som = getal1 + getal2
    return som

awnser = sommeer(10, 7)

print(f'het atwoord is {awnser}')










#def operator (getal1, getal2, opderator):
#     if operator == '/':
#         result = getal1 / getal2
#     elif operator == '*':
#         result = getal1 * getal2
#     else:
#         result = 0
        
#     return result

# g1 = int(input('getal1? '))
# g2 = int(input('getal2? '))
# op = input('operator')
# print (operator(g1, g2, op))