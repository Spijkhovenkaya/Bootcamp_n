woordenLijst = []

for x in range(5):
    woord = input("Voer een woord in...")
    woordenLijst.append(woord) 

print(f"De lijst met ingevoerde woorden is:")

for woord in woordenLijst :
    print (woord)