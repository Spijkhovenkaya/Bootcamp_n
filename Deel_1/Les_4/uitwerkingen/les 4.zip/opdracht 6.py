# de fout zit hem in het haakje wat vergeten is achter (2*3 /4)
print( ((2*3 /4) + (5 -6/7) *8 ))
print( ((12*13 /14) + (15 -16) /17) *18 ) 
# hier zitten geen fouten in