seconden_per_minuut = 60
minuten_per_uur = 60
uren_per_dag = 24
dagen_per_week = 7
dagen_per_jaar = 366

seconden_per_dag = seconden_per_minuut * minuten_per_uur * uren_per_dag
seconden_per_week = seconden_per_dag * dagen_per_week
seconden_per_jaar = seconden_per_dag * dagen_per_jaar

print(f"Aantal seconden in een dag: {seconden_per_dag}")
print(f"Aantal seconden in een week: {seconden_per_week}")
print(f"Aantal seconden in een jaar: {seconden_per_jaar}")