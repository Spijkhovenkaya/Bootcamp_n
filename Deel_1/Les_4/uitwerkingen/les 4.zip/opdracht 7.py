# Eerst reken ik 431/100 uit dat is 4,31 dan doe ik dit weer *100 en dan krijg je weer 431
print( (431 / 100) * 100 )