# dan geeft dees een fout door omdat geen een getal kan delen door 0 het blijft het zelfde

25/0
