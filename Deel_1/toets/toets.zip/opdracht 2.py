print(6 > 3 or 2 < 3) 		# print: True
print(3 > 6 or 2 < 3) 		# print: True
print('a' == 'a' or 'a' == 'b') # print: True
print(9 > 3 and 5 > 4)  		# print: True