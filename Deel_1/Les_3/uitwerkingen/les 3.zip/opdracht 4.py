# om opmerkingen neer te zetten gebruik ik crlt/
woord_1 = input ("wat voor weer is het?")
stad_1 = input ("in welke stad is het mooi weer")
naam_1 = input ("wat is jou naam")
woord_3 = input ("waar ben jij naar op zoek zoals ketting")
woord_4 = input ("wat voor vrouw zie jij")
woord_5 = input ("wat verkoopt de vrouw")
woord_6 = input ("waar kwam hij aan")
woord_zin_7 = input ("wat waren de mensen aan het doen")

print ('Het was een ' + woord_1 + 'dag in' + stad_1 + naam_1 + ' liep door de straten,op zoek naar een ' + woord_3 + ' plotsling zag ' +  naam_1 + ' een ' + woord_4 +  ' vrouw die een ' + woord_5 + ' verkocht. ' +naam_1+ ' besloot om hem te kopen en liep verder. Toen ' +  naam_1+ ' bij een ' + woord_6+ ' kwam,zag hij een groep mensen die ' + woord_zin_7 + naam_1 + ' besloot om mee te doen en had de tijd van zijn leven ')