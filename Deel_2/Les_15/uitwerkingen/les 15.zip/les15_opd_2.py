def sommeer(getal1, getal2): # parameters kun je gebruiken als var in je functie
    som = getal1 + getal2
    return som

def vermeningvuldiging(x, y):
    pass

print(vermeningvuldiging(3, 5))

pietje = sommeer(2, 17)

print(f'het atwoord is {pietje}')


#cijfer1 = int(input('wat is de eerste cijfer?: '))

# cijfer2 = int(input('wat is de eerste cijfer?: '))

# awnser = cijfer1 * cijfer2

# print(awnser)


