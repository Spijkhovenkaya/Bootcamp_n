totaal = 625
deler = 13

aantal_keer = totaal // deler

overblijfsel = totaal % deler
print(f"{deler} past {aantal_keer} keer in {totaal}")
print(f"Er blijft {overblijfsel} over.")
# 13 past 48 keer in 625 Er blijft 1 over.
