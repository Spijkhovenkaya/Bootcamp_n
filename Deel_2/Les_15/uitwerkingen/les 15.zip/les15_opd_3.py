from user_input import *

integer_value = get_integer("Voer een integer in: ")
print("Ingevoerde integer:", integer_value)

float_value = get_float("Voer een float in: ")
print("Ingevoerde float:", float_value)

string_value = get_string("Voer een string in: ")
print("Ingevoerde string:", string_value)

letter_value = get_letter("Voer één letter in: ")
print("Ingevoerde letter:", letter_value)
