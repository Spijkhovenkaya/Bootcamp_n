A=3.40
B=2.45
C=1.95

totaal = A+B+C
print(totaal)

totaal2 = totaal / 100
print (totaal2)

totaal3 = totaal2 * 9
print (totaal3)
