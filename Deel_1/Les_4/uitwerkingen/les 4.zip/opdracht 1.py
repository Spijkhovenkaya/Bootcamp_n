# dit werkt omdat de keer min en deel sommen in de software gebouwd staan
print( 15+4 )
print( 15-4 )
print( 15*4 )
print( 15/4 )
print( 15//4 )
print( 15**4 )
print( 15%4 )