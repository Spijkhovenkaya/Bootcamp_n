print( 3* "hallo" ) 
# hij zet hallo er drie keer in omdat ik 3*hallo neer heb gezet