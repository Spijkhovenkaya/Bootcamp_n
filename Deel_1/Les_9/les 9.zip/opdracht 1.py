a=5
b=3
c=2
if (a==6 and b==4 or c==2):
   print("De conditie is waar")
else: 
   print("De conditie is niet waar")	

a=5
b=3
c=2
if (a==6 and (b==4 or c==2)):
   print("De conditie is waar")
else:
   print("De conditie is niet waar")
#    de eerste is correct want hij rekent ze allemaal uit
# de tweede is fout want hij rekent daar eerst b==4 or c==2 uit 