getal1= float(input ("cijfer 1"))
getal2= float(input ("cijfer 2"))
getal3= float(input ("cijfer 3"))

gemiddelde = (getal1 + getal2 + getal3 ) / 3 
print(f"Het gemiddelde is: {gemiddelde}") 