if x == 18:
    print('de waarde van x = 18')

#Oude code
#  x = 18:
# print('de waarde van x = 18')"