eigen_naam = input ("wat is jou naam")

print ('Hallo ik ben' + eigen_naam + ',ik leer nu programmeren.' )
# niks is veranderd