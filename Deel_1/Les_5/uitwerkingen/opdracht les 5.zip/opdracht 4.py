straal = float(input("Voer de straal van de cirkel in: "))
pi = 3.14159
oppervlakte = straal ** 2 * pi
omtrek = 2 * pi * straal

print("De oppervlakte van een cirkel met straal", straal, "is", oppervlakte)
print("De omtrek van een cirkel met straal", straal, "is", omtrek)