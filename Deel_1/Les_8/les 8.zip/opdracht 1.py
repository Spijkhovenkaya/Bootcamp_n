cijfer = input("Wat is jou toets cijfer: ")

try:
    cijfer = int(cijfer)
    
    if 1 <= cijfer <= 10:
        if cijfer == 10:
            omschrijving = "geweldig"
        elif cijfer == 9:
            omschrijving = "zeer goed"
        elif cijfer == 8:
            omschrijving = "goed"
        elif cijfer == 7:
            omschrijving = "ruim voldoende"
        elif cijfer == 6:
            omschrijving = "voldoende"
        elif cijfer == 5:
            omschrijving = "bijna voldoende"
        elif cijfer == 4:
            omschrijving = "onvoldoende"
        elif cijfer == 3:
            omschrijving = "slecht"
        elif cijfer == 2:
            omschrijving = "zeer slecht"
        elif cijfer == 1:
            omschrijving = "absolute bagger"
        
        if cijfer >= 6:
            print(f"Gefeliciteerd, {omschrijving}, je resultaat is een {cijfer},goed gedaan!!")
        else:
            print(f"Jammer, {omschrijving}, je resultaat is een {cijfer},volgende keer beter!!")
    else:
        print("Dit kan ik niet omzetten! Voer een getal tussen 1 en 10 in.")
except ValueError:
    print("Dit is geen geldige invoer. Voer een getal tussen 1 en 10 in.")
