print(1115*21)
