fruitLijst = ["appel" , "peer" , "perzik" , "pruim" , "banaan", "kiwi"]

print (fruitLijst)

gekozenFruit = input("Kies een fruit die uit de lijst moet...")

fruitLijst.remove (gekozenFruit)

print (fruitLijst)